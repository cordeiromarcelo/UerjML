from app.source.preprocessing.functions.colunas import *
from app.source.preprocessing.functions.numerico import *
from app.source.preprocessing.functions.tratamento import *
