# UerjML

Uma plataforma de Machine Learning brasileira e gratuita, construira com fins educacionais.